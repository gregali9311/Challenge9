# SchoolChallenge: Node_JS_SchoolProj
## License Number: License2

Got questions? Look at the code [here](https://github.com/gregali9311)
Not enough? Email me at: gjali@asu.edu
        
## Project Description
        
        This project will leverage node JS to create a readme file as indicated in the user story and acceptance criteria. 
        
        
## Installation Guide
        
        In order to install the project, navigate to the Githubrepo and find the code that correlates to the readme creation. In order to use the code , download it locally, and install on your machine 
        
        
## Usage Info
        
        You can use however you like. Please make contributions as enhancements arise 
        
## Contribution Guidelines
        
        Yes Please. Do this. 
        
## Testing Instructions
        
        In order to validate if the code is working, run it. If it doesn't provide a readme, then you know for sure. 